gsap.registerPlugin(ScrollTrigger);

/* -------- Scroll reveals -------- */
gsap.utils.toArray('.reveal-up').forEach((el) => {
  const delay =
    el.classList.contains('delay-1') ? 0.15 :
    el.classList.contains('delay-2') ? 0.30 : 0;

  gsap.from(el, {
    opacity: 0,
    y: 80,
    duration: 1.2,
    ease: 'power3.out',
    delay,
    scrollTrigger: { trigger: el, start: 'top 85%' }
  });
});

gsap.utils.toArray('.reveal-left').forEach(el => {
  gsap.from(el, {
    opacity: 0,
    x: -80,
    duration: 1.2,
    ease: 'power3.out',
    scrollTrigger: { trigger: el, start: 'top 85%' }
  });
});

gsap.utils.toArray('.reveal-right').forEach(el => {
  gsap.from(el, {
    opacity: 0,
    x: 80,
    duration: 1.2,
    ease: 'power3.out',
    scrollTrigger: { trigger: el, start: 'top 85%' }
  });
});

/* -------- Footer year -------- */
const yearEl = document.getElementById('yearNow');
if (yearEl) yearEl.textContent = new Date().getFullYear();

/* -------- Copy contract -------- */
const copyBtn = document.getElementById('copyContract');
const contractEl = document.getElementById('contractValue');

if (copyBtn && contractEl) {
  copyBtn.addEventListener('click', async () => {
    const text = contractEl.textContent.trim();
    try {
      await navigator.clipboard.writeText(text);
      const prev = copyBtn.textContent;
      copyBtn.textContent = 'Copied';
      setTimeout(() => (copyBtn.textContent = prev), 1200);
    } catch (e) {
      const ta = document.createElement('textarea');
      ta.value = text;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      ta.remove();

      const prev = copyBtn.textContent;
      copyBtn.textContent = 'Copied';
      setTimeout(() => (copyBtn.textContent = prev), 1200);
    }
  });
}

/* -------- Language toggle RU/EN -------- */
const dict = {
  en: {
    hdr_subtitle: "The Degen Engine on TON",
    nav_about: "About",
    nav_how: "How it works",
    nav_tokenomics: "Tokenomics",
    nav_faq: "FAQ",
    nav_links: "Links",

    hero_sub: "Building a real economy around scarce Telegram usernames",
    hero_cta: "Enter Strategy",

    how_title: "How It Works",
    how_s1: "We acquire usernames across different price ranges based on market opportunities.",
    how_s2: "We hold and manage supply to strengthen scarcity and increase demand.",
    how_s3: "We resell usernames with a strategic markup (≈25%).",
    how_s4: "100% of the profit is used to buy back $USERSTR and burn it — reducing supply and increasing token value.",

    flow_title: "STRATEGY FLOW",
    flow_h1: "Username acquisition",
    flow_t1: "We buy premium and mid-range Telegram usernames across key markets.",
    flow_h2: "Resale & profit",
    flow_t2: "Usernames are resold with ≈25% markup, creating realized profit.",
    flow_h3: "Buyback",
    flow_t3: "All profit is used to buy $USERSTR back directly from the market.",
    flow_h4: "Burn",
    flow_t4: "Bought tokens are burned, reducing supply and reinforcing value.",

    old_card1_h: "Acquire",
    old_card1_t: "Placeholder text describing step one.",
    old_card2_h: "Hold",
    old_card2_t: "Placeholder text describing step two.",
    old_card3_h: "Monetize",
    old_card3_t: "Placeholder text describing step three.",

    tok_title: "Tokenomics",
    tok_tax: "Taxes",
    tok_split_lbl: "After 10% trade tax split",
    tok_split_note: "Protocol / Team / Team 2",
    tok_chain: "Blockchain",
    tok_ca: "Contract Address",
    tok_copy: "Copy",
    old_tok1: "Supply Distribution",
    old_tok2: "Buyback & Burn",

    vision_title: "Our Vision",
    vision_text: "This is a placeholder glass section. Background animation or video can be placed behind.",
    vision_cta: "Explore Vision",

    faq_title: "FAQ",
    faq_q1: "What is Usernames Strategy?",
    faq_a1: "Temporary placeholder answer.",
    faq_q2: "How does value grow?",
    faq_a2: "Temporary placeholder answer.",
    faq_q3: "Is it transparent?",
    faq_a3: "Temporary placeholder answer.",

    links_title: "Links",
    links_note: "We will add links to DEX, wallet and socials here later.",
    links_tg: "Community & updates",
    links_dex: "Buy / Sell $USERSTR",
    links_x: "News & highlights",

    cta_title: "Ready to Start?",
    cta_text: "Placeholder call to action section.",
    cta_btn: "Launch App",

    footer_pow: "Powered by TON.",
    footer_up: "Up",
  },

  ru: {
    hdr_subtitle: "The Degen Engine on TON",
    nav_about: "О проекте",
    nav_how: "Как работает",
    nav_tokenomics: "Токеномика",
    nav_faq: "FAQ",
    nav_links: "Ссылки",

    hero_sub: "Строим реальную экономику вокруг дефицитных Telegram-юзернеймов",
    hero_cta: "Войти в Strategy",

    how_title: "How It Works",
    how_s1: "Мы выкупаем юзернеймы в разных ценовых диапазонах, исходя из рыночных возможностей.",
    how_s2: "Мы удерживаем и управляем предложением, усиливая дефицит и спрос.",
    how_s3: "Мы перепродаём юзернеймы со стратегической наценкой (≈25%).",
    how_s4: "100% прибыли идёт на выкуп $USERSTR с рынка и сжигание — уменьшая предложение и усиливая ценность токена.",

    flow_title: "STRATEGY FLOW",
    flow_h1: "Покупка юзернеймов",
    flow_t1: "Покупаем premium и mid-range юзернеймы на ключевых рынках.",
    flow_h2: "Перепродажа и прибыль",
    flow_t2: "Перепродаём с ≈25% наценкой, фиксируя прибыль.",
    flow_h3: "Выкуп",
    flow_t3: "Вся прибыль идёт на выкуп $USERSTR напрямую с рынка.",
    flow_h4: "Сжигание",
    flow_t4: "Выкупленные токены сжигаются, уменьшая supply и укрепляя ценность.",

    old_card1_h: "Покупаем",
    old_card1_t: "Временная заглушка текста.",
    old_card2_h: "Держим",
    old_card2_t: "Временная заглушка текста.",
    old_card3_h: "Монетизируем",
    old_card3_t: "Временная заглушка текста.",

    tok_title: "Tokenomics",
    tok_tax: "Налог",
    tok_split_lbl: "После разделения 10% налога",
    tok_split_note: "Протокол / Команда / Команда 2",
    tok_chain: "Блокчейн",
    tok_ca: "Адрес контракта",
    tok_copy: "Copy",
    old_tok1: "Распределение supply",
    old_tok2: "Выкуп и сжигание",

    vision_title: "Видение",
    vision_text: "Временная glass-секция. Сюда можно поставить видео/анимацию на фон и текст сверху.",
    vision_cta: "Открыть видение",

    faq_title: "FAQ",
    faq_q1: "Что такое Usernames Strategy?",
    faq_a1: "Временная заглушка ответа.",
    faq_q2: "Как растёт ценность?",
    faq_a2: "Временная заглушка ответа.",
    faq_q3: "Это прозрачно?",
    faq_a3: "Временная заглушка ответа.",

    links_title: "Links",
    links_note: "Тут позже добавим ссылки на биржи, кошелёк и соцсети.",
    links_tg: "Комьюнити и апдейты",
    links_dex: "Купить / Продать $USERSTR",
    links_x: "Новости и хайлайты",

    cta_title: "Готов начать?",
    cta_text: "Временная заглушка CTA.",
    cta_btn: "Запустить",

    footer_pow: "Powered by TON.",
    footer_up: "Наверх",
  }
};

function applyLang(lang) {
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.getAttribute('data-i18n');
    const val = dict?.[lang]?.[key];
    if (val) el.textContent = val;
  });

  const langLabel = document.getElementById('langLabel');
  if (langLabel) langLabel.textContent = (lang === 'ru' ? 'RU' : 'EN');
  document.documentElement.lang = lang;
  localStorage.setItem('lang', lang);
}

const langToggle = document.getElementById('langToggle');
const stored = localStorage.getItem('lang');
let currentLang = stored === 'en' ? 'en' : 'ru';
applyLang(currentLang);

if (langToggle) {
  langToggle.addEventListener('click', () => {
    currentLang = (currentLang === 'ru') ? 'en' : 'ru';
    applyLang(currentLang);
  });
}

/* -------- Header offset scroll fix -------- */
const header = document.querySelector('.site-header');
const headerH = header ? header.offsetHeight : 0;

document.querySelectorAll('a[href^="#"]').forEach(a => {
  a.addEventListener('click', (e) => {
    const id = a.getAttribute('href');
    if (!id || id === '#') return;
    const target = document.querySelector(id);
    if (!target) return;

    e.preventDefault();
    const y = target.getBoundingClientRect().top + window.scrollY - headerH - 10;
    window.scrollTo({ top: y, behavior: 'smooth' });
  });
});

/* =========================================================
   ✅ Deep mouse-follow tilt for How cards (SPAACE-like)
   Applies ONLY to .cards .card
   ========================================================= */
document.querySelectorAll('.cards .card').forEach(card => {
  let raf = null;

  card.addEventListener('mousemove', e => {
    const r = card.getBoundingClientRect();
    const px = (e.clientX - r.left) / r.width - 0.5;
    const py = (e.clientY - r.top) / r.height - 0.5;

    const dist = Math.sqrt(px * px + py * py);

    const rotateY = px * 22;
    const rotateX = -py * 14;
    const translateZ = 18 + dist * 40;
    const translateX = px * 14;
    const translateY = py * 10;

    card.style.setProperty('--mx', `${(px + 0.5) * 100}%`);
    card.style.setProperty('--my', `${(py + 0.5) * 100}%`);

    if (raf) cancelAnimationFrame(raf);
    raf = requestAnimationFrame(() => {
      card.style.transform = `
        perspective(1100px)
        translateX(${translateX}px)
        translateY(${translateY}px)
        translateZ(${translateZ}px)
        rotateY(${rotateY}deg)
        rotateX(${rotateX}deg)
      `;
    });
  });

  card.addEventListener('mouseleave', () => {
    if (raf) cancelAnimationFrame(raf);

    card.style.transition = 'transform 0.9s cubic-bezier(.18,.9,.22,1)';
    card.style.transform = 'perspective(1100px) rotateX(0) rotateY(0) translateZ(0)';
    card.style.setProperty('--mx', '50%');
    card.style.setProperty('--my', '50%');

    setTimeout(() => {
      card.style.transition = '';
    }, 900);
  });
});
